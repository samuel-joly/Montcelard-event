document.addEventListener("DOMContentLoaded", (e) => {
    let start_date = document.querySelector("input[name=\"start-date\"]");
    console.log(start_date);
});
